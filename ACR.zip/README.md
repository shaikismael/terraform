# Azure Container Registry
### Argument Reference
The following arguments are supported:

- name - (Required) Specifies the name of the Container Registry. Changing this forces a new resource to be created.

- resource_group_name - (Required) The name of the resource group in which to create the Container Registry. Changing this forces a new resource to be created.

- location - (Required) Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created.

- admin_enabled - (Optional) Specifies whether the admin user is enabled. Defaults to false.

- storage_account_id - (Required for Classic Sku - Forbidden otherwise) The ID of a Storage Account which must be located in the same Azure Region as the Container Registry. Changing this forces a new resource to be created.

- sku - (Optional) The SKU name of the container registry. Possible values are Basic, Standard and Premium. Classic (which was previously Basic) is supported only for existing resources.

NOTE:
The Classic SKU is Deprecated and will no longer be available for new resources from the end of March 2019.

- tags - (Optional) A mapping of tags to assign to the resource.

- georeplication_locations - (Optional / Deprecated in favor of georeplications) A list of Azure locations where the container registry should be geo-replicated.

NOTE:
The georeplication_locations is only supported on new resources with the Premium SKU.

NOTE:
The georeplication_locations list cannot contain the location where the Container Registry exists.

NOTE:
The georeplication_locations is deprecated, use georeplications instead.

- georeplications - (Optional) A georeplications block as documented below.
NOTE:
The georeplications is only supported on new resources with the Premium SKU.

NOTE:
The georeplications list cannot contain the location where the Container Registry exists.

- network_rule_set - (Optional) A network_rule_set block as documented below.

- public_network_access_enabled - (Optional) Whether public network access is allowed for the container registry. Defaults to true.

- quarantine_policy_enabled - (Optional) Boolean value that indicates whether quarantine policy is enabled. Defaults to false.

- retention_policy - (Optional) A retention_policy block as documented below.

- trust_policy - (Optional) A trust_policy block as documented below.

- zone_redundancy_enabled - (Optional) Whether zone redundancy is enabled for this Container Registry? Changing this forces a new resource to be created. Defaults to false.

NOTE:
quarantine_policy_enabled, retention_policy, trust_policy and zone_redundancy_enabled are only supported on resources with the Premium SKU.

- identity - (Optional) An identity block as documented below.

- encryption - (Optional) An encryption block as documented below.

- georeplications supports the following:

- location - (Required) A location where the container registry should be geo-replicated.

- zone_redundancy_enabled - (Optional) Whether zone redundancy is enabled for this replication location? Defaults to false.

- tags - (Optional) A mapping of tags to assign to this replication location.

- network_rule_set supports the following:

- default_action - (Optional) The behaviour for requests matching no rules. Either Allow or Deny. Defaults to Allow

- ip_rule - (Optional) One or more ip_rule blocks as defined below.

- virtual_network - (Optional) One or more virtual_network blocks as defined below.

NOTE:
network_rule_set is only supported with the Premium SKU at this time.

NOTE:
Azure automatically configures Network Rules - to remove these you'll need to specify an network_rule_set block with default_action set to Deny.

- ip_rule supports the following:

- action - (Required) The behaviour for requests matching this rule. At this time the only supported value is Allow

- ip_range - (Required) The CIDR block from which requests will match the rule.

- virtual_network supports the following:

- action - (Required) The behaviour for requests matching this rule. At this time the only supported value is Allow

- subnet_id - (Required) The subnet id from which requests will match the rule.

- trust_policy supports the following:

- enabled - (Optional) Boolean value that indicates whether the policy is enabled.
retention_policy supports the following:

- days - (Optional) The number of days to retain an untagged manifest after which it gets purged. Default is 7.

- enabled - (Optional) Boolean value that indicates whether the policy is enabled.

identity supports the following:

- type - (Required) The type of Managed Identity which should be assigned to the Container Registry. Possible values are SystemAssigned, UserAssigned and SystemAssigned, UserAssigned.

- identity_ids - (Optional) A list of User Managed Identity ID's which should be assigned to the Container Registry.

- encryption supports the following:

- enabled - (Optional) Boolean value that indicates whether encryption is enabled.

- key_vault_key_id - (Required) The ID of the Key Vault Key.

- identity_client_id - (Required) The client ID of the managed identity associated with the encryption key.

NOTE
The managed identity used in encryption also needs to be part of the identity block under identity_ids

Attributes Reference
The following attributes are exported:

- id - The ID of the Container Registry.

- login_server - The URL that can be used to log into the container registry.

- admin_username - The Username associated with the Container Registry Admin account - if the admin account is enabled.

- admin_password - The Password associated with the Container Registry Admin account - if the admin account is enabled.

- identity - An identity block as defined below, which contains the Managed Service Identity information for this Container Registry.

A identity block exports the following:

- principal_id - The Principal ID for the Service Principal associated with the Managed Service Identity of this Container Registry.

- tenant_id - The Tenant ID for the Service Principal associated with the Managed Service Identity of this Container Registry.

Note
You can access the Principal ID via azurerm_container_registry.example.identity.0.principal_id and the Tenant ID via azurerm_container_registry.example.identity.0.tenant_id

Timeouts
The timeouts block allows you to specify timeouts for certain actions:

- create - (Defaults to 30 minutes) Used when creating the Container Registry.
- update - (Defaults to 30 minutes) Used when updating the Container Registry.
- read - (Defaults to 5 minutes) Used when retrieving the Container Registry.
- delete - (Defaults to 30 minutes) Used when deleting the Container Registry.