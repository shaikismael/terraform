# Azure KeyVault:
This Terraform module creates an Azure Key Vault with :

1. Diagnostic settings enabled and can send the logs & metrics to 2 destinations which are Log analystics workspace and to storage account.
2. Create defined Metric Alerts and Log Alerts for Key vault.
3. Create the alert mechanism to setup alerts for Metric and Log Alerts
4. Enable "admin" access to Service Principal which used to create this Keyvault by default.

## Assumptions /Pre-Requisites:
Below resources are already created in same regions where Kev Vault will be created.

1. Resource Group is already created.
2. Log analystics workspace is already created.
3. Storage account is already created. 

You can use this module by including it this way:

# KeyVault Module

```
module "keyvault" {

  source                          = "git::https://barings@dev.azure.com/barings/PortfolioCentral/_git/IaCCodeRepository//modules//KeyVault?ref=modulesf3"
  app_name                        = var.app_name
  app_env                         = var.app_env
  key_vault_name                  = var.new_kv_name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  sku_name                        = lower(var.kv_sku_name)
  soft_delete_retention_days      = var.soft_delete_retention_days
  purge_protection_enabled        = var.purge_protection_enabled
  enabled_for_deployment          = var.enabled_for_deployment
  enabled_for_disk_encryption     = var.enabled_for_disk_encryption
  enabled_for_template_deployment = var.enabled_for_template_deployment
  enable_rbac_authorization       = var.enable_rbac_authorization
  log_analytics_workspace_name = var.log_analytics_workspace_name
  log_storage_name             = var.log_storage_name
  logs                         = var.logs
  metrics                      = var.metrics
}

```

## Inputs:

1. new_kv_name:  Name of the Key Vault, generated if not set.	
2. location: Azure location for Key Vault.	
3. resource_group_name : Resource Group the resources will belongs to and where KV should be created.
4. sku_name	: The Name of the SKU used for this Key Vault. Possible values are "standard" and "premium".
5. tenant_id	The Azure Active Directory tenant ID that should be used for authenticating requests to the Key Vault. Default is the current one.
6. soft_delete_retention_days : Number of days to keep logs on storage account	
7. purge_protection_enabled : Whether to activate purge protection	
8. enabled_for_deployment: Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault.	
9. enabled_for_disk_encryption: Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys.	
10. enabled_for_template_deployment : Boolean flag to specify whether Azure Resource Manager is permitted to retrieve secrets from the key vault.	
11. enable_rbac_authorization: Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions.
12. log_analytics_workspace_name : Specifies the Name of a Log Analytics Workspace where Diagnostics Data to be sent
13. log_storage_name : The name of the storage account to store the all monitoring logs where Diagnostics Data to be sent
14. logs = Enter maximum 5 log set as mentioned below for which diagnostics should be enabled.

```hcl

  {
    category_name      = Specify log category name to decide which logs category logs should send be enabled.
    Diagnostics_enable = Boolean flag to specify to enable Diagnostics
    Retention_enable   = Whether to enable the log retention 
    Retention_days     = Specify Log retention days 
  }
```
15. metrics = Enter maximum 5 metrics set as mentioned below for which diagnostics should be enabled.

```hcl
  {
    category_name      = Specify log category name to decide which logs category logs should send be enabled.
    Diagnostics_enable = Boolean flag to specify to enable Diagnostics
    Retention_enable   = Whether to enable the log retention 
    Retention_days     = Specify Log retention days 
  }

```
## Outputs:

1. key_vault_id	: Id of the Key Vault
2. key_vault_name: 	Name of the Key Vault
3.  key_vault_uri: 	URI of the Key Vault
